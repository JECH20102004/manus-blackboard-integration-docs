# 📦 Blackboard UVM → Notion Student Dashboard (Paquete Completo) - README en Español

Este paquete contiene **todo lo necesario** para integrar Blackboard con tu Dashboard de Notion usando **OpenManus**.

## 📂 Contenido

- `starter_kit/`
  - Contexto completo del proyecto (Markdown + PDF).
  - `.env.example` con todas las variables sanitizadas.
  - `cli/run_sync.py` → script de prueba/ejecución inicial.
  - `images/notion_collage.png` → collage de las capturas de tu base en Notion.
  - `setup.sh` → script de instalación en Linux/Mac.
  - `setup.bat` → script de instalación en Windows.
- `OpenManus/`
  - Código fuente de **OpenManus** (tal como lo subiste).
  - Úsalo como orquestador de agentes/tools para correr el sync real.

## 🚀 Pasos de uso

1. **Descomprime el paquete** en tu máquina local.
2. Entra a `starter_kit/` y copia `.env.example` → `.env`.  
   Rellena con tus credenciales reales de Blackboard y Notion (después de rotarlas).
3. Opcional: coloca tus capturas de Notion en `starter_kit/images/`.
4. Ejecuta el script de instalación según tu sistema operativo:
   - Linux/Mac: `bash starter_kit/setup.sh`
   - Windows: `starter_kit\setup.bat`
5. Verifica la salida del health-check. Si todo va bien, tendrás la confirmación de conexión con Blackboard y Notion.
6. Integra el **starter kit** con **OpenManus** (carpeta `OpenManus/`) siguiendo la guía del `README` en inglés.

## 🗺️ Diagrama de uso (Mermaid)

```mermaid
flowchart TD
  A[Descomprimir paquete] --> B[Editar starter_kit/.env con credenciales]
  B --> C[Agregar capturas a starter_kit/images/ (opcional)]
  C --> D[Ejecutar script de verificación]
  D -->|python starter_kit/cli/run_sync.py --check| E{¿OK?}
  E -- No --> F[Revisar variables / rotar claves / reintentar]
  E -- Sí --> G[Abrir carpeta OpenManus/]
  G --> H[Integrar tools/clients del starter_kit en OpenManus]
  H --> I[Configurar workflow del agente (sync Blackboard→Notion)]
  I --> J[Ejecutar sync incremental con idempotencia]
  J --> K[Verificar Notion: Courses/Assignments/Relations]
  K --> L[Programar ejecución (cron/CI/CD)]
```

## 🔐 Seguridad

- Nunca publiques tu `.env` real.
- Rota claves si se expusieron en algún chat o documento.
- Usa scopes mínimos tanto en Blackboard como en Notion.

---

© Edgar Cota — Proyecto académico/personal.
