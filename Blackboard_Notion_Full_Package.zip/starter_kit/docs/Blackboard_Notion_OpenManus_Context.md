
# 📑 Proyecto: Sync Blackboard UVM → Notion Student Dashboard (con OpenManus / Manús IA)

> **Autor:** Edgar Cota  
> **Propósito del archivo:** Entregar a otra IA **todo el contexto en un único documento** para que proponga/complete la estructura del proyecto y/o genere código base.

---

## ⚠️ Seguridad (leer antes)
Este documento contiene **credenciales que el usuario pegó previamente**. Si vas a compartirlo fuera de un entorno controlado, **usa la versión SANITIZADA** de las variables o elimina el **Apéndice S-1**. Recomendación: **rotar** cualquier secreto que ya se haya expuesto públicamente.

---

## 1) Contexto general
- **Orquestador:** OpenManus (agente + tools / “herramientas” invocables por IA).
- **Origen:** Blackboard Learn (UVM) — recursos: **Courses, Assignments, Grades, Announcements, Content** + **feed ICS** (calendario).
- **Destino:** **Notion Student Dashboard** compuesto por **múltiples databases relacionadas** (no es una sola tabla):
  - `Courses`
  - `Assignments`
  - `Exams`
  - `Notes` / `Notebooks`
  - *(Opcional)* `Announcements`, `Content`, `Events`, `Grades (attempts)`
- **Objetivo:** Sincronizar Blackboard → Notion con:
  - **Idempotencia** por `external_id`.
  - **Delta-sync** por `updated_at / modified` (paginación y backoff ante 429).
  - **Relaciones** correctas (Assignments/Exams ↔ Course).

---

## 2) Enlace de la base de Notion
**URL:** https://www.notion.so/Student-Dashboard-25f20e8891638084a110de6a4f0d8168

> Nota: El ID visible al final del enlace (`25f20e8891638084a110de6a4f0d8168`) corresponde a la página/database. Confirmar que cada sub-DB (Courses, Assignments, etc.) tiene su **ID específico**, que se usará en las variables de entorno.

---

## 3) Capturas de la base (para referencia visual)
> Inserta/adjunta los archivos de imagen correspondientes. Abajo se colocan marcadores con nombres sugeridos.  
> Si tu entorno lo soporta, guarda las 4 capturas como PNG y colócalas en la carpeta `images/` junto a este archivo.

- **Courses (vista galería):**
  ![Courses Gallery](images/01_courses_gallery.png)

- **Course / Math (propiedades principales):**
  ![Course Math - propiedades 1](images/02_course_math_a.png)
  ![Course Math - propiedades 2](images/03_course_math_b.png)

- **Dashboard general (Quick Capture / Navigation):**
  ![Student Dashboard Home](images/04_student_dashboard.png)

> Estas capturas muestran que el dashboard está compuesto por varias **databases** y **relaciones**, en especial: `Courses` ↔ `Assignments`/`Exams`/`Notes`.

---

## 4) Variables de entorno (SANITIZADAS para compartir)
Usar **estos nombres** de variables; **NO** pegar secretos reales en prompts públicos:

```ini
# Blackboard (sanitizado)
BB_DOMAIN=https://uvmonline.blackboard.com
BB_CLIENT_ID=__REPLACE_ME__
BB_CLIENT_SECRET=__REPLACE_ME__
BB_REDIRECT_URI=https://TU-DOMINIO/oauth/callback/blackboard
BB_SCOPES=courses.read announcements.read assignments.read calendar.read
ICS_URL=https://uvmonline.blackboard.com/webapps/calendar/calendarFeed/__REPLACE__/learn.ics
TIMEZONE=America/Mazatlan

# Notion (sanitizado)
NOTION_API_KEY=__REPLACE_ME__
NOTION_VERSION=2022-06-28

# IDs de Notion DBs (colocar los reales de cada DB)
NOTION_DB_COURSES=__COURSES_DB_ID__
NOTION_DB_ASSIGNMENTS=__ASSIGNMENTS_DB_ID__
NOTION_DB_EXAMS=__EXAMS_DB_ID__
NOTION_DB_NOTES=__NOTES_DB_ID__
# Opcionales
NOTION_DB_ANNOUNCEMENTS=__ANNOUNCEMENTS_DB_ID__
NOTION_DB_CONTENT=__CONTENT_DB_ID__
NOTION_DB_EVENTS=__EVENTS_DB_ID__
NOTION_DB_GRADES=__GRADES_DB_ID__
```

---

## 5) Diagrama ER (Notion ↔ Blackboard)
```mermaid
erDiagram
  BB_COURSE ||--o{ BB_ASSIGNMENT : "has"
  BB_COURSE ||--o{ BB_EXAM       : "has (subset of assignments)"
  BB_COURSE ||--o{ BB_ANNOUNCEMENT : "has"
  BB_COURSE ||--o{ BB_CONTENT      : "has"
  BB_ASSIGNMENT ||--o{ BB_GRADEATTEMPT : "has attempts"
  BB_COURSE ||--o{ ICS_EVENT : "calendar feed"

  NOTION_COURSES ||--o{ NOTION_ASSIGNMENTS : "Relation"
  NOTION_COURSES ||--o{ NOTION_EXAMS       : "Relation"
  NOTION_COURSES ||--o{ NOTION_NOTES       : "Relation"
  NOTION_COURSES ||--o{ NOTION_ANNOUNCEMENTS : "Relation (opt)"
  NOTION_COURSES ||--o{ NOTION_CONTENT       : "Relation (opt)"
  NOTION_COURSES ||--o{ NOTION_EVENTS        : "Relation (opt)"
  NOTION_ASSIGNMENTS ||--o{ NOTION_GRADES   : "1..* attempts (opt)"
```

---

## 6) Esquemas esperados por Database (Notion)
> Si alguna propiedad no existe, permitir **configurar mapping** o crear opciones `Select` on-demand.

### Courses
- `title` (Title), `external_id` (Text), `Status` (Select), `Semester` (Text/Select),
  `Course Code` (Text), `Location` (Text), `Time` (Text),
  `Professor` (Text), `Email` (Email), `Syllabus` (File/URL opcional),
  `updated_at` (Date), `url` (URL),
  **Relations**: `Assignments`, `Exams`, `Notes` (+ opcionales `Announcements/Content/Events`).

### Assignments
- `title`, `external_id`, `Course` (Relation→Courses),
  `type` (Select=`assignment`), `status` (Select: `posted|submitted|graded|closed`),
  `points` (Number), `grade` (Number), `due_at` (Date), `updated_at` (Date), `url` (URL), `raw` (Text).

### Exams
- Igual que Assignments pero `type=exam`.

### Opcionales
- `Announcements`, `Content`, `Events`, `Grades` (attempts).

---

## 7) Diccionario de mapeo (resumen)
| Blackboard → campo | Notion (DB/prop) | Transformación |
|---|---|---|
| `course.id` | Courses.`external_id` | `bb:course:{id}` |
| `course.name` | Courses.`title` | texto |
| `course.courseId/code` | Courses.`Course Code` | texto |
| `term` | Courses.`Semester` | texto/select |
| `schedule` | Courses.`Time` | texto |
| `location` | Courses.`Location` | texto |
| `instructorName` | Courses.`Professor` | texto |
| `instructorEmail` | Courses.`Email` | email |
| `modified` | Courses.`updated_at` | ISO8601 (UTC) |
| `assignment.id` | Assignments.`external_id` | `bb:asg:{id}` |
| `assignment.title` | Assignments.`title` | texto |
| `assignment.courseId` | Assignments.`Course` | relation por `bb:course:{id}` |
| `pointsPossible` | Assignments.`points` | número |
| `dueDate` | Assignments.`due_at` | ISO8601 (UTC) |
| `status` | Assignments.`status` | select (crear opción si falta) |
| attempt.`score` | Assignments.`grade` | último intento (Fase 1) |
| `exam.*` | Exams.* | igual que Assignments (`type=exam`) |
| `announcement.*` | (Notes/Announcements).* | `raw` truncado |
| `content.*` | (Notes/Content).* | url/type |
| ICS `uid,start` | Events.`external_id`,`due_at` | `ics:{uid}`, fecha inicio |

---

## 8) Reglas de sincronización
- **Idempotencia:** upsert por `external_id` (`bb:*` o `ics:*`).
- **Relaciones:** resolver Course por `external_id = bb:course:{id}` (fallback por `Course Code`).  
- **Delta-sync:** filtrar por `modified/updated_at` si el API lo permite; si no, comparar en cliente.  
- **Paginación & límites:** Blackboard (paging/headers) y Notion (≤100/batch).  
- **Selects:** crear opciones si no existen (evitar errores de validación).  
- **Fechas:** normalizar a **UTC ISO8601**; mostrar en `TIMEZONE`.

---

## 9) Estructura deseada del proyecto (OpenManus)
```
/openmanus-sync
  /agent
    main_agent.{py|ts}            # registra tools y workflow
  /tools
    blackboard_tool.{py|ts}       # REST + paginación + backoff
    notion_tool.{py|ts}           # query/upsert + relaciones
  /domain
    models.{py|ts}                # Course, Assignment, Exam, Grade, Announcement, Content, Event
    normalizers.{py|ts}
    upsert_policy.{py|ts}
  /infra
    rate_limit.{py|ts}
    logger.{py|ts}
    config.{py|ts}
  /cli
    run_sync.{py|ts}              # ejecución sin UI
  /tests
    unit/ integration/ e2e/
  .env.example
  Dockerfile
  README.md
```

---

## 10) Contratos de función (signatures objetivo)
**Blackboard tool**
- `oauth_token() -> str`
- `list_courses(updated_after: str|None) -> Iterable[CourseRaw]`
- `list_announcements(course_id, updated_after) -> Iterable[AnnRaw]`
- `list_assignments(course_id, updated_after) -> Iterable[AsgRaw]`
- `list_grades(course_id, assignment_id, updated_after) -> Iterable[AttemptRaw]`
- `list_content(course_id, updated_after) -> Iterable[ContentRaw]`
- `parse_ics(ics_url: str) -> Iterable[IcsEventRaw]`

**Normalizers**
- `normalize_course(raw) -> Course`
- `normalize_assignment(course, raw) -> Assignment`
- `normalize_exam(course, raw) -> Exam`
- `normalize_grade(course, assignment, raw) -> Grade`
- `normalize_announcement(course, raw) -> Announcement`
- `normalize_content(course, raw) -> Content`
- `normalize_event(raw) -> Event`

**Notion tool**
- `find_course_by_external_id(ext_id) -> NotionPageId|None`
- `upsert_course(course: Course) -> UpsertResult`
- `upsert_assignment(assignment: Assignment) -> UpsertResult`
- `upsert_exam(exam: Exam) -> UpsertResult`
- `upsert_announcement(...)`, `upsert_content(...)`, `upsert_event(...)`
- `relate_assignment_to_course(assignment_page_id, course_page_id)`

**Workflow**
- `run_sync(last_run: str|None) -> SyncReport`

---

## 11) Pseudocódigo del ciclo principal
```python
def run_sync(last_run_iso: str | None):
    courses_raw = list_courses(updated_after=last_run_iso)
    for c_raw in courses_raw:
        c = normalize_course(c_raw)
        c_page = upsert_course(c)

        for a_raw in list_assignments(c.bb_id, updated_after=last_run_iso):
            a = normalize_assignment(c, a_raw)
            a_page = upsert_assignment(a)
            relate_assignment_to_course(a_page, c_page)

            attempts = list_grades(c.bb_id, a.bb_id, updated_after=last_run_iso)
            a.grade = pick_latest_score(attempts)
            upsert_assignment(a)  # update con grade

        for e_raw in list_exams_like(c.bb_id, updated_after=last_run_iso):
            e = normalize_exam(c, e_raw)
            e_page = upsert_exam(e)
            relate_exam_to_course(e_page, c_page)

        for ann_raw in list_announcements(c.bb_id, updated_after=last_run_iso):
            upsert_announcement(normalize_announcement(c, ann_raw))

        for cont_raw in list_content(c.bb_id, updated_after=last_run_iso):
            upsert_content(normalize_content(c, cont_raw))

    for ics_raw in parse_ics(ICS_URL):
        upsert_event(normalize_event(ics_raw))
```

---

## 12) Métricas, logs y criterios
- **Métricas:** `courses_created/updated`, `assignments_created/updated`, `errors`, `retries`, `rate_limit_hits`; duraciones por etapa; `last_run` persistido.
- **Criterios de aceptación:** upsert sin duplicados, relaciones correctas, delta-sync real, resiliencia a 429/5xx, batching ≤100, fechas en UTC.

---

## Apéndice S-1) Variables **originales** que el usuario pegó (SENSIBLES ⚠️)
> Solo para **uso local** y si ya rotaste/validadte el riesgo. **No redistribuir.**

```ini
# 🔐 Blackboard UVM (original del usuario)
BB_DOMAIN=https://uvmonline.blackboard.com/
BB_CLIENT_ID=6c91c466-5a6f-4194-8094-aa21bbffd9ae
BB_CLIENT_SECRET=67322a01-8279-4399-a065-deabedc00a7f
BB_REDIRECT_URI=https://TU-DOMINIO/oauth/callback/blackboard
BB_SCOPES=courses.read announcements.read assignments.read calendar.read
ICS_URL=https://uvmonline.blackboard.com/webapps/calendar/calendarFeed/99ad4329268447ff9c18813cebcf5570/learn.ics
TIMEZONE=America/Mazatlan

# 🧠 Notion IA (original del usuario)
NOTION_API_KEY=ntn_f883376573144yA20bdaxjH7gVG3O3IHFaYmiBYDvWIaJz
NOTION_DB_MAIN=25e20e88916380b6a732e5ca4fccb545

# 📌 Notion API version
NOTION_VERSION=2022-06-28
```

> **Recomendación:** Mantener este apéndice en un archivo separado y privado (`secrets.local.md`) o, preferiblemente, usar `.env` local y **NO** incluirlo en documentos compartidos.
