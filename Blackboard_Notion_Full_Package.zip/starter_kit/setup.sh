#!/usr/bin/env bash
set -euo pipefail

echo "==> Blackboard UVM → Notion Starter Kit (OpenManus) - Setup"

# 1) Check Python
if ! command -v python3 >/dev/null 2>&1; then
  echo "❌ Python3 no está instalado. Instálalo y vuelve a ejecutar."
  exit 1
fi

# 2) Go to starter_kit
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
STARTER_DIR="$ROOT_DIR/starter_kit"
cd "$STARTER_DIR"

# 3) Create venv
echo "==> Creando entorno virtual .venv"
python3 -m venv .venv
source .venv/bin/activate

# 4) Upgrade pip
python -m pip install --upgrade pip

# 5) Install minimal deps
echo "==> Instalando dependencias mínimas"
python -m pip install requests python-dotenv pytz ics

# 6) Prepare .env
if [ ! -f ".env" ]; then
  echo "==> Creando .env desde .env.example"
  cp .env.example .env
  echo "⚠️  Abre starter_kit/.env y coloca tus credenciales reales (después de rotarlas si fue necesario)."
fi

# 7) Health-check
echo "==> Ejecutando verificación rápida"
python cli/run_sync.py --check || true

cat << 'EOF'

✅ Setup completo.

Siguientes pasos:
1) Edita starter_kit/.env con tus credenciales reales (Blackboard/Notion) y los IDs de tus databases de Notion.
2) (Opcional) Agrega capturas a starter_kit/images/.
3) Ejecuta el flujo demo:
   source .venv/bin/activate && python cli/run_sync.py
4) Integra el starter kit con OpenManus (carpeta OpenManus/) siguiendo el README.

EOF


echo "📌 Recuerda: tu destino de sincronización en Notion es: https://www.notion.so/Student-Dashboard-25f20e8891638084a110de6a4f0d8168"
