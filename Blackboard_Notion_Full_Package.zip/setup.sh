#!/bin/bash
# ================================================
#  Setup Script for Blackboard → Notion Sync
#  Using OpenManus + Starter Kit
# ================================================

echo "🚀 Iniciando setup..."

# 1) Crear entorno virtual (Python 3.11+)
python3 -m venv .venv
source .venv/bin/activate

# 2) Actualizar pip
pip install --upgrade pip

# 3) Instalar dependencias mínimas
pip install requests python-dotenv pytz ics

echo "✅ Dependencias instaladas."

# 4) Crear archivo .env desde ejemplo si no existe
if [ ! -f .env ]; then
  cp starter_kit/.env.example .env
  echo "⚠️  Se creó .env desde starter_kit/.env.example. Edítalo y coloca tus claves reales."
fi

# 5) Mensaje final
echo "🎉 Setup listo. Ahora puedes ejecutar:"
echo "    source .venv/bin/activate"
echo "    python starter_kit/cli/run_sync.py --check"
