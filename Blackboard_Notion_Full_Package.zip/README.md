# 📦 Blackboard UVM → Notion Student Dashboard (Full Package)

Este paquete contiene **todo lo necesario** para integrar Blackboard con tu Dashboard de Notion usando **OpenManus**.

## 📂 Contenido

- `starter_kit/`
  - Contexto completo del proyecto (Markdown + PDF).
  - `.env.example` con todas las variables sanitizadas.
  - `cli/run_sync.py` → script de prueba/ejecución inicial.
  - `images/notion_collage.png` → collage de las capturas de tu base en Notion.
- `OpenManus/`
  - Código fuente de **OpenManus** (tal como lo subiste).
  - Úsalo como orquestador de agentes/tools para correr el sync real.

## 🚀 Cómo usar

1. **Descomprime el paquete** en tu máquina local.
2. Entra a `starter_kit/` y copia `.env.example` → `.env`.  
   Rellena con tus credenciales reales de Blackboard y Notion (después de rotarlas).
3. Opcional: coloca tus capturas de Notion en `starter_kit/images/`.
4. Ejecuta el script de prueba:
   ```bash
   cd starter_kit/cli
   python run_sync.py --check
   ```
   Verás un **plan de sync demo**.
5. Para integrar con **OpenManus**, abre la carpeta `OpenManus/` y sigue su documentación, 
   usando como referencia los modelos, normalizadores y tools definidos en el `starter_kit/`.

## 🔐 Seguridad

- Nunca publiques tu `.env` real. Solo comparte `.env.example`.
- Rota claves si ya se expusieron en algún documento/chat.
- Usa scopes mínimos en Blackboard y Notion.

---

© Edgar Cota — Proyecto académico/personal. 


## 📊 Flujo de uso (visual)

```mermaid
flowchart TD
    A[Descargar ZIP] --> B[Descomprimir]
    B --> C[starter_kit/.env.example → .env]
    C --> D[Completar credenciales]
    D --> E[Ejecutar run_sync.py --check]
    E --> F{Health-check OK?}
    F -- No --> G[Revisar .env y credenciales]
    F -- Sí --> H[run_sync.py]
    H --> I[Sync Blackboard → Notion]
    I --> J[Revisión en Notion Dashboard]
    J --> K[Iterar con OpenManus en OpenManus/]
```


## 🗺️ Diagrama de uso (Mermaid)

```mermaid
flowchart TD
  A[Descargar y descomprimir paquete] --> B[Editar starter_kit/.env con credenciales]
  B --> C[Opcional: agregar capturas a starter_kit/images/]
  C --> D[Ejecutar script de verificación]
  D -->|python starter_kit/cli/run_sync.py --check| E{¿OK?}
  E -- No --> F[Revisar variables/rotar claves/reintentar]
  E -- Sí --> G[Abrir carpeta OpenManus/]
  G --> H[Integrar tools/clients del starter_kit en OpenManus]
  H --> I[Configurar workflow de agente (sync Blackboard→Notion)]
  I --> J[Ejecutar sync incremental con idempotencia]
  J --> K[Verificar Notion: Courses/Assignments/Relations]
  K --> L[Programar ejecución (cron/CI/CD)]
```
